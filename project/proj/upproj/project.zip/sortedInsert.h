#ifndef SORTED_INSERT /* Include guard */
#define SORTED_INSERT

void sortedInsert(node **head_ref, node *new_node);

#endif 
