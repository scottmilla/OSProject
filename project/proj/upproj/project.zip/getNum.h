#ifndef GET_NUM  /* Include guard */
#define GET_NUM

int getNum(char *str);

#endif 
