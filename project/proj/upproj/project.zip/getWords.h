#ifndef GET_WORDS_   /* Include guard */
#define GET_WORDS_

int getWords(char *buf, char target[10][20]);  

#endif 
