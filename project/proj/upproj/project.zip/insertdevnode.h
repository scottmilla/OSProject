#ifndef INSERT_DEV_NODE /* Include guard */
#define INSERT_DEV_NODE

void insertdevnode(node *n);

#endif 
