#ifndef READ_FILE /* Include guard */
#define READ_FILE

int readFile(int argc, char *argv[]);

#endif 
