#ifndef INSERT_READY /* Include guard */
#define INSERT_READY

void insertReady(node *n);

#endif 
