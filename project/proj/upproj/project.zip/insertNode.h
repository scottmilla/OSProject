#ifndef INSERT_NODE  /* Include guard */
#define INSERT_NODE

void insertNode(node *n);

#endif 
